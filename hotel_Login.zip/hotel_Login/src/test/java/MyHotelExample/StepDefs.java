package MyHotelExample;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import hotel_Login.LoginPageFactory;
import hotel_Login.PageFactoryAppHotel;
import hotel_Login.PaymentsPageFactory;

public class StepDefs {

	WebDriver driver;
	PageFactoryAppHotel login1 ;
	LoginPageFactory login2;
	PaymentsPageFactory pyfac;

	@Given("^launch the application browser take to the login page$")
	public void launch_the_application_browser_take_to_the_login_page() throws Throwable {
		// WebElement element;

		System.setProperty("webdriver.chrome.driver", "C:/My_Ravi_wi_fi server/chromedriver_win32/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("C:/My_Ravi_wi_fi server/BDD/login.html");
		driver.manage().window().maximize();
	}

	@When("^User enters the valid username and valid password$")
	public void user_enters_the_valid_username_and_valid_password() throws Throwable {
		login1= new PageFactoryAppHotel(driver);
		login1.login_misapp("alphy", "alphy");
		 driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
	}

	@Then("^Application takes to the 'Hotel booking' page$")
	public void application_takes_to_the_Hotel_booking_page() throws Throwable {
       
		System.out.println("Invalid username and password");
		/*LoginPageFactory login2 = new LoginPageFactory(driver);
		login2.login_misapp2( "Ravi", "Kumar",
				"Wer@gmail.com","321456987", "mum", "airoli"); 
		Thread.sleep(100000);*/
	}
	
	@Given("^User launches the browser and opens the application$")
	public void user_launches_the_browser_and_opens_the_application() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:/My_Ravi_wi_fi server/chromedriver_win32/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("C:/My_Ravi_wi_fi server/BDD/login.html");
		driver.manage().window().maximize();
	}

	/*@Given("^User has the valid username and passowrd$")
	public void user_has_the_valid_username_and_passowrd() throws Throwable {
		login1= new PageFactoryAppHotel(driver);
		login1.login_misapp("capgemini", "capg1234");
		 driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
	}*/

	@When("^User enters the \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_enters_the_and(String arg1, String arg2) throws Throwable {
	
		login1= new PageFactoryAppHotel(driver);
		login1.login_misapp("capgemini", "capg1234");
		 driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
		 }
	

@Then("^Application redirect to 'Hotel booking' page$")
public void application_redirect_to_Hotel_booking_page() throws Throwable {
	LoginPageFactory login1 = new LoginPageFactory(driver);
	login1.login_misapp2("Ravi", "Gupta", "rkumar2185@gmail.com", "9214569887", "New Ashok Nagar, New Delhi", "Pune","Karnataka","2");
	PaymentsPageFactory pyfac = new PaymentsPageFactory(driver);
	pyfac.payment_card("Ravi Gupta", "78945", "113", "03", "1996");
	 driver.findElement(By.xpath("//*[@id=\"btnPayment\"]")).click();
	Thread.sleep(100000);
}



}
