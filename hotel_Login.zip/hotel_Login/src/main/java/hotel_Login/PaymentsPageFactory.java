package hotel_Login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PaymentsPageFactory {


	WebDriver driver;

	// creating parameterized constructor to initialize WebDriver reference
	public PaymentsPageFactory(WebDriver driver) {
		this.driver = driver;
		// This initElements method will create all WebElements
		PageFactory.initElements(driver, this);

	}

	

	@FindBy(id = "txtCardholderName")
	@CacheLookup // to store the element in cache memory
	WebElement cardHolderNam;

	@FindBy(name = "debit")
	@CacheLookup // to store the element in cache memory
	WebElement debitcard;

	

	@FindBy(name = "cvv")
	@CacheLookup // to store the element in cache memory
	WebElement cVV;

	
	@FindBy(name = "month")
	@CacheLookup // to store the element in cache memory
	WebElement Month;
	
	@FindBy(name = "year")
	@CacheLookup // to store the element in cache memory
	WebElement Year;
	

	public void payment_card( String cn, String debit,
			String cv,String mnth, String yerr ) {
		cardHolderNam.sendKeys(cn);
		debitcard.sendKeys(debit);
		cVV.sendKeys(cv);
		Month.sendKeys(mnth);
		Year.sendKeys(yerr);
		
		

	}
}
