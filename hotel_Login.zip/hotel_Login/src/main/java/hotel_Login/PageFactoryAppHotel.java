package hotel_Login;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PageFactoryAppHotel {
	
	WebDriver driver;

	// creating parameterized constructor to initialize WebDriver reference
	public PageFactoryAppHotel(WebDriver driver) {
		this.driver = driver;
		// This initElements method will create all WebElements
		PageFactory.initElements(driver, this);

	}
	
	@FindBy(name = "userName")
	@CacheLookup // to store the element in cache memory
	WebElement username;

	// using How class
	@FindBy(name = "userPwd")
	@CacheLookup
	WebElement password;
	
	public void login_misapp(String un, String pass ) {
		username.sendKeys(un);
		password.sendKeys(pass);

	}
}
