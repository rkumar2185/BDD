package hotel_Login;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class LoginPageFactory {
	

	WebDriver driver;

	// creating parameterized constructor to initialize WebDriver reference
	public LoginPageFactory(WebDriver driver) {
		this.driver = driver;
		// This initElements method will create all WebElements
		PageFactory.initElements(driver, this);

	}

	

	@FindBy(name = "txtFN")
	@CacheLookup // to store the element in cache memory
	WebElement firstname;

	@FindBy(name = "txtLN")
	@CacheLookup // to store the element in cache memory
	WebElement lastname;

	

	@FindBy(name = "Email")
	@CacheLookup // to store the element in cache memory
	WebElement eMail;

	
	@FindBy(id = "txtPhone")
	@CacheLookup // to store the element in cache memory
	WebElement txtPhn;
	
	
	@FindBy(xpath = "/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")
	@CacheLookup // to store the element in cache memory
	WebElement address;


	@FindBy(name = "city")
	@CacheLookup
	WebElement select;

	@FindBy(name = "state")
	@CacheLookup
	WebElement select1;
	

	@FindBy(name = "persons")
	@CacheLookup
	WebElement select2;


	public void login_misapp2( String fn, String ln,
			String email,String phn, String add, String cty,String stat,String gst ) {
		firstname.sendKeys(fn);
		lastname.sendKeys(ln);
		eMail.sendKeys(email);
		txtPhn.sendKeys(phn);
		address.sendKeys(add);
		Select city = new Select(driver.findElement(By.name("city")));
		city.selectByVisibleText(cty);
		Select stat2 = new Select(driver.findElement(By.name("state")));
		stat2.selectByVisibleText(stat);
		Select gust = new Select(driver.findElement(By.name("persons")));
		gust.selectByVisibleText(gst);
		

	}


}
