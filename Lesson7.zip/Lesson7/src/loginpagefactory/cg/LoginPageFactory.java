package loginpagefactory.cg;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class LoginPageFactory {

	WebDriver driver;

	// creating parameterized constructor to initialize WebDriver reference
	public LoginPageFactory(WebDriver driver) {
		this.driver = driver;
		// This initElements method will create all WebElements
		PageFactory.initElements(driver, this);

	}

	@FindBy(id = "txtUserName")
	@CacheLookup // to store the element in cache memory
	WebElement username;

	// using How class
	@FindBy(how = How.ID, using = "txtPassword")
	@CacheLookup
	WebElement password;

	// using Xpath
	@FindBy(how = How.XPATH, using = "//*[@id='txtConfPassword']")
	@CacheLookup
	WebElement confrmpass;

	@FindBy(name = "txtFN")
	@CacheLookup // to store the element in cache memory
	WebElement firstname;

	@FindBy(name = "txtLN")
	@CacheLookup // to store the element in cache memory
	WebElement lastname;

	@FindBy(name = "DtOB")
	@CacheLookup // to store the element in cache memory
	WebElement dob;

	@FindBy(name = "Email")
	@CacheLookup // to store the element in cache memory
	WebElement eMail;

	@FindBy(id = "txtAddress")
	@CacheLookup // to store the element in cache memory
	WebElement address;

	@FindBy(name = "gender")
	@CacheLookup // to store the element in cache memory
	List<WebElement> radioElem;

	@FindBy(name = "City")
	@CacheLookup
	WebElement select;

	@FindBy(id = "txtPhone")
	@CacheLookup // to store the element in cache memory
	WebElement txtPhn;

	@FindBy(name = "chkHobbies")
	@CacheLookup // to store the element in cache memory
	List<WebElement> checkElem;

	// List<WebElement> checkElem = driver.findElements(By.name("chkHobbies"));

	public void login_misapp(String un, String pass, String cpass, String fn, String ln, String gen, String db,
			String email, String add, String cty, String phn, String hoby) {
		username.sendKeys(un);
		password.sendKeys(pass);
		confrmpass.sendKeys(cpass);
		firstname.sendKeys(fn);
		lastname.sendKeys(ln);
		for (WebElement webElement : radioElem) {
			String radioSelection;
			radioSelection = webElement.getAttribute("value").toString();
			if (radioSelection.equals(gen)) {
				webElement.click();
			}

			try {
				Thread.sleep(500);
			} catch (InterruptedException ex) {
				System.out.println(ex.getMessage());
			}
		}
		dob.sendKeys(db);
		eMail.sendKeys(email);
		address.sendKeys(add);
		Select stat = new Select(driver.findElement(By.name("City")));
		stat.selectByVisibleText(cty);
		txtPhn.sendKeys(phn);

		for (WebElement webElement : checkElem) {
			String checkSelection;
			checkSelection = webElement.getAttribute("value").toString();
			if (checkSelection.equals(hoby)) {
				webElement.click();
			}

			try {
				Thread.sleep(500);
			} catch (InterruptedException ex) {
				System.out.println(ex.getMessage());
			}
		}

		driver.findElement(By.xpath("/html/body/form/table/tbody/tr[13]/td/input")).click();

	}

}
