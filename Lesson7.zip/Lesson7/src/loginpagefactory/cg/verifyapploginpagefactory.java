package loginpagefactory.cg;

import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class verifyapploginpagefactory {
	
	@Test
	public void veryfylogin()
	{
		System.setProperty("webdriver.chrome.driver", "C:/BDD Jar Files/chromedriver_win32/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/UpdatedSTS/WorkingWithForms.html");
		driver.manage().window().maximize();
	// creating object of LoginPage class
		
		LoginPageFactory login1 = new LoginPageFactory(driver);
		login1.login_misapp("alphy","alphy","alphy","Shubahm","Maurya","Male","20-09-1995","shubhb@SKM.CPM","LKO","Mumbai","123456789","Movies");
	//	login.typeusername();
		//login.typeconfirmpwd();
		
		
	}

}
