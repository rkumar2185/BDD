import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByClassName;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class CloseAndQuitDemo {
	public static void main(String args []) throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver","C:/BDD Jar Files/chromedriver_win32/chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("file:///C:/UpdatedSTS/WorkingWithForms.html");
		driver.manage().window().maximize();
		Thread.sleep(10);
		
		//driver.findElement(By.linkText("Login")).click();
		
		WebElement  userName=driver.findElement(By.name("txtUName" ));
		userName.sendKeys("Ghost_47");
		Thread.sleep(10);
		
		
        WebElement password=driver.findElement(By.id("txtPassword" ));
		password.sendKeys("UcantCme007");
		Thread.sleep(10);
	
		
		
         WebElement confPassword=driver.findElement(By.id("txtConfPassword" ));
		confPassword.sendKeys("UcantCme007");
		Thread.sleep(10);
	
		
		
		WebElement firstName=driver.findElement(By.name("txtFN" ));
		firstName.sendKeys("Shubham");
		Thread.sleep(10);
		
		
		WebElement lastName=driver.findElement(By.name("txtLN" ));
		lastName.sendKeys("Maurya");
		Thread.sleep(10);
		
		driver.findElement(By.id("rbMale")).click();
		
		
		WebElement DOB=driver.findElement(By.name("DtOB" ));
		DOB.sendKeys("20-09-1995");
		Thread.sleep(10);
		
		
		
		WebElement email=driver.findElement(By.name("Email" ));
	    email.sendKeys("shubh.maurya@gmail.com");
		Thread.sleep(100);
		
		WebElement address=driver.findElement(By.id("txtAddress" ));
		address.sendKeys("LUCKNOW");
		Thread.sleep(100);
		
		Select kb=new Select(driver.findElement(By.name("City" )));
					kb.selectByVisibleText("Mumbai");
					
		WebElement phn=driver.findElement(By.id("txtPhone" ));
		phn.sendKeys("99999999");
		Thread.sleep(100);	
		
		driver.findElement(By.cssSelector("body > form > table > tbody > tr:nth-child(12) > td:nth-child(2) > input[type=\"checkbox\"]:nth-child(3)" )).click();
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("/html/body/form/table/tbody/tr[13]/td/input")).click();
		Thread.sleep(1000);
		
		//driver.findElement(By.xpath("/html/body/form/table/tbody/tr[13]/td/input")).click();
	//Thread.sleep(1000);
	
		

		Alert alert=driver.switchTo().alert();
		System.out.println("Successfully Submitted"+ alert.getText());
		alert.accept();
		
		driver.quit();
		
		
		
		
		
	}

}
