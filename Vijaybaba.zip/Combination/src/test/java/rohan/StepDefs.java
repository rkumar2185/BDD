package rohan;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageFactoryrohan.pageFrohan;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefs 
{
	WebDriver driver;
	pageFrohan roh;
	
	@Given("^open the browser and launch the application$")
	public void open_the_browser_and_launch_the_application() throws Throwable 
	{
		System.setProperty
        ("webdriver.chrome.driver",
        "C:\\Users\\vijghosh\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
	 driver = new ChromeDriver();
    driver.manage().window().maximize();
    
	   driver.get("file:///C:/Users/vijghosh/Downloads/WorkingWithForms%20(6).html");
	   roh=new pageFrohan(driver);
	}

	@When("^fill the details$")
	public void fill_the_details() throws Throwable 
	{
		roh.setName("vijay");
		roh.setPassword("ghjk");
		roh.setCnpassword("ghjk");
		roh.setFirstname("rohan");
		roh.setLastname("vijay");
		roh.setGen("Male");
		roh.setDate("11-02-1995");
		roh.setEmail("abc@gmail.com");
		roh.setAddress("mumbai");
		roh.setCity("Mumbai");
		roh.setPhone("456321");
		roh.setHobbies("Music", "Movies");
		
	    
	}

	@When("^click on the submit button$")
	public void click_on_the_submit_button() throws Throwable 
	{
		roh.setSubmit();
	    
	}

	@Then("^verify the alert popup$")
	public void verify_the_alert_popup() throws Throwable 
	{
		Alert alert=driver.switchTo().alert();
		String alertText=alert.getText();
		assertEquals("Submitted",alertText);
		Thread.sleep(5000);
		alert.accept();
		driver.close();
	    
	}

}
