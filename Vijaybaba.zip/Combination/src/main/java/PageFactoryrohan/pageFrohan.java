package PageFactoryrohan;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class pageFrohan 
{
	WebDriver driver;
	
	public pageFrohan(WebDriver driver)
	{
		// TODO Auto-generated constructor stub
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(name="txtUName")
	@CacheLookup
	WebElement name;
	
	@FindBy(id="txtPassword")
	@CacheLookup
	WebElement password;
	
	@FindBy(id="txtConfPassword")
	@CacheLookup
	WebElement cnpassword;
	
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement firstname;
	
	
	@FindBy(name="txtLN")
	@CacheLookup
	WebElement lastname;
	
	

	@FindBy(name="gender")
	@CacheLookup
	List<WebElement> gen;
	
	
	@FindBy(name="DtOB")
	@CacheLookup
	WebElement date;
	
	

	@FindBy(name="Email")
	@CacheLookup
	WebElement email;
	
	
	@FindBy(name="Address")
	@CacheLookup
	WebElement address;
	
	
	@FindBy(name="City")
	@CacheLookup
	WebElement city;
	
	
	@FindBy(name="Phone")
	@CacheLookup
	WebElement phone;
	
	

	@FindBy(name="chkHobbies")
	@CacheLookup
	List<WebElement> hobbies;
	
	
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[13]/td/input")
	@CacheLookup
	WebElement submit;

	public WebElement getName() {
		return name;
	}



	public void setName(String nme) {
		this.name.sendKeys(nme);
	}



	public WebElement getPassword() {
		return password;
	}



	public void setPassword(String pass) {
		this.password.sendKeys(pass);
	}



	public WebElement getCnpassword() {
		return cnpassword;
	}



	public void setCnpassword(String cnpass) {
		this.cnpassword.sendKeys(cnpass);
	}



	public WebElement getFirstname() {
		return firstname;
	}



	public void setFirstname(String fname) {
		this.firstname.sendKeys(fname);
	}



	public WebElement getLastname() {
		return lastname;
	}



	public void setLastname(String lname) {
		this.lastname.sendKeys(lname);
	}



	public List<WebElement> getGen() {
		return gen;
	}


	//for radio button
	public void setGen(String gender) {
		for(WebElement gend:gen) {
			String radioSelection;
    		radioSelection = gend.getAttribute("value").toString();
    		 if(radioSelection.equals(gender))
             {
                 gend.click();
             }
                                         
		}
	}



	public WebElement getDate() {
		return date;
	}



	public void setDate(String dat) {
		this.date.sendKeys(dat);
	}



	public WebElement getEmail() {
		return email;
	}



	public void setEmail(String mail) {
		this.email.sendKeys(mail);
	}



	public WebElement getAddress() {
		return address;
	}



	public void setAddress(String addr) {
		this.address.sendKeys(addr);
	}



	public WebElement getCity() {
		return city;
	}


	//for drop down
	public void setCity(String cit) {
	Select cities=new Select(city);
	cities.selectByVisibleText(cit);
	}



	public WebElement getPhone() {
		return phone;
	}



	public void setPhone(String phn) {
		this.phone.sendKeys(phn);
	}



	public List<WebElement> getHobbies() {
		return hobbies;
	}



	public void setHobbies(String  hobbie, String hobb) {
		for(WebElement hobby: hobbies) {
			String checkbox;
			checkbox = hobby.getAttribute("value").toString();
    		 if(checkbox.equals(hobbie)||checkbox.equals(hobb))
             {
                 hobby.click();
             }
		}
	}



	public WebElement getSubmit() {
		return submit;
	}



	public void setSubmit() {
		this.submit.click();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
