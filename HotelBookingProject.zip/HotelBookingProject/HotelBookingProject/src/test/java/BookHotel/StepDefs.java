package BookHotel;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import hotelbooking.HotelBookingpageFactory;

public class StepDefs

{
	WebDriver driver;
	// private String username;
	// private String password;
	HotelBookingpageFactory pagefactoryobj;

	@When("^User enters invalid username and invalid password$")
	public void user_enters_invalid_username_and_invalid_password() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		driver.findElement(By.name("userName")).sendKeys("capgemini");
		// driver.findElement(By.name("userPwd")).sendKeys("capg1234");
		driver.findElement(By.className("btn")).click();
		// Thread.sleep(5000);

	}

	@Then("^it shows Error Message$")
	public void it_shows_Error_Message() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String errmsg = driver.findElement(By.id("pwdErrMsg")).getText();
		String experrmsg = "* Please enter password.";
		assertEquals(errmsg, experrmsg);
		Thread.sleep(100);

	}

	@Given("^User launches the browser and goes to login\\.html page$")
	public void user_launches_the_browser_and_goes_to_login_html_page() throws Throwable {

		System.setProperty("webdriver.chrome.driver", "C:/My_Ravi_wi_fi server/chromedriver_win32/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("C:/My_Ravi_wi_fi server/BDD/login.html");

	}

	@When("^Login page Heading comes as Hotel Booking Application$")
	public void login_page_Heading_comes_as_Hotel_Booking_Application() throws Throwable {
		String head = driver.findElement(By.cssSelector("#mainCnt > div > div:nth-child(1) > h1")).getText();
		System.out.println(head);
		assertEquals("Hotel Booking Application", head);
	}

	@Then("^user enters \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_enters_and(String arg1, String arg2) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		driver.findElement(By.name("userName")).sendKeys("capgemini");
		driver.findElement(By.name("userPwd")).sendKeys("capg1234");
		// Thread.sleep(10000);
		driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();

	}

	@Then("^Application takes to Hotel Booking page$")
	public void application_takes_to_Hotel_Booking_page() throws Throwable {
		driver.get("C:/My_Ravi_wi_fi server/BDD/hotelbooking.html");

	}

	@Given("^User is on the Hotel Booking Form$")
	public void user_is_on_the_Hotel_Booking_Form() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		pagefactoryobj = new HotelBookingpageFactory(driver);

		System.setProperty("webdriver.chrome.driver", "C:/My_Ravi_wi_fi server/chromedriver_win32/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("C:/My_Ravi_wi_fi server/BDD/login.html");

	}

	@When("^User Fills all the details correctly$")
	public void user_Fills_all_the_details_correctly() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		driver.get("C:/My_Ravi_wi_fi server/BDD/hotelbooking.html");
		pagefactoryobj = new HotelBookingpageFactory(driver);

		pagefactoryobj.setFormfirstname("Alphy");
		// Thread.sleep(500);
		// driver.close();
		pagefactoryobj.setFormlastname("Thomson");
		pagefactoryobj.setFormemail("abc@gmail.com");
		pagefactoryobj.setFormfone("9234567890");
		pagefactoryobj.setFormaddress("Whitefield,Bangalore");
		pagefactoryobj.setFormcity("Bangalore");
		pagefactoryobj.setFormstate("Karnataka");
		pagefactoryobj.setFormnoofpersons("3");
		pagefactoryobj.setFormcardholdername("Alphy T");
		pagefactoryobj.setFormdebitCardno("13459045872");
		pagefactoryobj.setFormCVV("123");
		pagefactoryobj.setFormexpmonth("Jan");
		pagefactoryobj.setFormexpyear("2020");

		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(5000);

	}

	@Then("^It shows te success message$")
	public void it_shows_te_success_message() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String actualmsg = pagefactoryobj.getsuccessmsg();
		String expectedmsg = "Booking Completed!";
		assertEquals(actualmsg, expectedmsg);
		driver.close();

	}

}
